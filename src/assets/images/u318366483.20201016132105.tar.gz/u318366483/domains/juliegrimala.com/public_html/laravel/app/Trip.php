<?php
// app\Trip.php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Trip extends Model
{
    protected $fillable = ['date', 'driver', 'typetrip', 'depart', 'arrivee', 'singleTrip', 'distance', 'vehicle'];

    public function user()
    {
        return $this->belongsTo('App\User', 'trip_driver', 'trip_id');
    }

    public function users()
    {
        return $this->belongsToMany('App\User', 'trip_id', 'user_id')->withTimestamps();
    }
}