@extends('layouts.master') <!-- name of folder . name of blade.php file -->

@section('content') <!-- to avoid breaking the html code -->
    <p class="quote">Accueil</p>
    <h1 class="post-title">Bonjour!</h1>
@endsection