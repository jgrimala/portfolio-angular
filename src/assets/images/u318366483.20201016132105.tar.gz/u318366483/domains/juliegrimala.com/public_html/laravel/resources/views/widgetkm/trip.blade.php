@extends('layouts.master')
<!-- resources\views\widgetkm\trip.blade.php -->
@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Kilométrage du : {{ $trip->date }}</p>
        </div>
    </div>
    <div class="row">
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Conducteur : {{ $trip->driver }}</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Type de voyage : {{ $trip->typetrip }}</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Point de départ : {{ $trip->depart }}</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Destination : {{ $trip->arrivee }}</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Allée simple/retour : @if($trip->singleTrip)
                 {{'Aller simple'}} 
            @else {{ 'Aller-retour'}} </p>
            @endif
        
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Distance totale : {{ $trip->distance }} km</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Véhicule : {{ $trip->vehicle }}</p>
        </div>
    </div>
@endsection