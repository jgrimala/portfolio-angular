<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Tous les kilométrages</p>
        </div>
    </div>
    
    <div class="container">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Date de transport</th>
                <th scope="col">Conducteur</th>
                <th scope="col">Type de voyage</th>
                <th scope="col">Point de départ</th>
                <th scope="col">Destination</th>
                <th scope="col">Allée simple/retour</th>
                <th scope="col">Distance totale</th>
                <th scope="col">Véhicule</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="font-weight: bold"><?php echo e($trip->date); ?></td>
                <td><?php echo e($trip->driver); ?></td>
                <td><?php echo e($trip->typetrip); ?></td>
                <td><?php echo e($trip->depart); ?></td>
                <td><?php echo e($trip->arrivee); ?></td>
                <td><?php if($trip->singleTrip): ?>
                        <?php echo e('Aller simple'); ?> 
                    <?php else: ?> <?php echo e('Aller-retour'); ?>

                    <?php endif; ?></td>
                <td><?php if(!$trip->singleTrip): ?>
                        <?php echo e($trip->distance*2); ?> km
                    <?php else: ?> <?php echo e($trip->distance); ?> km
                    <?php endif; ?></td>
                <td><?php echo e($trip->vehicle); ?></td>
                <td><a href="<?php echo e(route('widgetkm.trip', ['id' => $trip->id])); ?>">Détails...</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </body>
    </table>
</div>
    <div class="row">
        <div class="col-md-12 text-center">
            <?php echo e($trips->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\juliekm\resources\views/widgetkm/index.blade.php ENDPATH**/ ?>