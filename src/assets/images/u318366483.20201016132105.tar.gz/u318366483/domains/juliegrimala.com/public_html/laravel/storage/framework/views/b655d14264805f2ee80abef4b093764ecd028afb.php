<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('admin.create')); ?>" method="post">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" name="date">
                </div>
                <div class="form-group">
                    <!--<label for="driver">Conducteur</label>
                    <select class="form-control" name="driver">
                        
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option id="driver" value="<?php echo e($user->name); ?>"> <?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>-->
                </div>

                <div class="form-group">
                    <label for="typetrip">Type de déplacement</label>
                    <select class="form-control" name="typetrip">
                            <option id="typetrip" value="personnel">personnel</option>
                            <option id="typetrip" value="chantier">chantier</option>
                            <option id="typetrip" value="quincaillerie">quincaillerie</option>
                            <option id="typetrip" value="rendez-vous">rendez-vous</option>
                            <option id="typetrip" value="administratif">comptable</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depart">Point de départ</label>
                    <input type="text" class="form-control" id="depart" name="depart">
                </div>
                <div class="form-group">
                    <label for="arrivee">Destination</label>
                    <input type="text" class="form-control" id="arrivee" name="arrivee">
                </div>
                        <input type="radio" name="singleTrip" id="singleTrip" value="1" selected>aller simple</option>
                        <input type="radio" name="singleTrip" id="singleTrip" value="0">aller-retour</option>
                <div class="form-group">
                    <label for="distance">Distance d'une allée simple</label>
                    <input type="text" class="form-control" id="distance" name="distance">
                </div>
                <div class="form-group">
                    <label for="vehicle">Véhicule</label>
                    <input type="text" class="form-control" id="vehicle" name="vehicle">
                </div>
                <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-primary">Ajouter</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u318366483/domains/juliegrimala.com/public_html/resources/views/admin/create.blade.php ENDPATH**/ ?>