@extends('layouts.master')
@section('content')
    @include('partials.errors')
    <div class="row">
        <div class="col-md-12">
            <form action="{{ route('admin.update') }}" method="post">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" name="date" value="{{ $trip->date }}">
                </div>
                <div class="form-group">
                    <label for="driver">Conducteur</label>
                    <input
                            type="text"
                            class="form-control"
                            id="driver"
                            name="driver"
                            value="{{ $trip->driver }}">
                </div>
                <div class="form-group">
                    <label for="typetrip">Type de déplacement</label>
                   
                    <select class="form-control" name="typetrip" value="{{ $trip->typetrip }}">
                            <option id="typetrip" name="typetrips[]" value="personnel">personnel</option>
                            <option id="typetrip" name="typetrips[]" value="chantier">chantier</option>
                            <option id="typetrip" name="typetrips[]" value="quincaillerie">quincaillerie</option>
                            <option id="typetrip" name="typetrips[]" value="rendez-vous">rendez-vous</option>
                            <option id="typetrip" name="typetrips[]" value="administratif">administratif</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depart">Point de départ</label>
                    <input type="text" class="form-control" id="depart" name="depart" value="{{ $trip->depart }}">
                </div>
                <div class="form-group">
                    <label for="arrivee">Destination</label>
                    <input type="text" class="form-control" id="arrivee" name="arrivee" value="{{ $trip->arrivee }}">
                </div>
                <div>
                    <label class="radio-inline">
                    <input type="radio" name="singleTrip" id="singleTrip" value="1" {{ ($trip->singleTrip == "1")? "checked" : "" }}>aller simple</option>
                    <label class="radio-inline">
                    <input type="radio" name="singleTrip" id="singleTrip" value="0" {{ ($trip->singleTrip == "0")? "checked" : "" }}>aller-retour</option>
                </div>
                    <div class="form-group">
                    <label for="distance">Distance d'un aller simple</label>
                    <input type="text" class="form-control" id="distance" name="distance" value="{{ $trip->distance }}">
                </div>
                <div class="form-group">
                    <label for="vehicle">Véhicule</label>
                    <input type="text" class="form-control" id="vehicle" name="vehicle" value="{{ $trip->vehicle }}">
                </div>
               
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{ $trip_id }}">
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
            </form>
        </div>
    </div>
@endsection