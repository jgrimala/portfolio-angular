<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="{{ route('widgetkm.index') }}" class="navbar-brand">Accueil</a>
            <ul class="nav navbar-nav">
                @if(Auth::check())
                <li><a href="{{ route('widgetkm.index') }}">Déplacements</a></li>
                @endif
                <li><a href="#">About</a></li>
                @if(!Auth::check())
                <li><a href="{{ url('/login') }}">s'identifier</a></li>
                <li><a href="{{ url('/register') }}">s'enregistrer</a></li>
                @else
                <li><a href="{{ route('admin.index') }}">Mon espace</a></li>
                <li>
                    <a href="{{ url('/logout') }}"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                        Se déconnecter
                    </a>

                    <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                        {{ csrf_field() }}
                    </form>
                </li>
                @endif
            </ul>
        </div>
    </div>
</nav>