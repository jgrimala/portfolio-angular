<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('admin.update')); ?>" method="post">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" class="form-control" id="date" name="date" value="<?php echo e($trip->date); ?>">
                </div>
                <div class="form-group">
                    <label for="driver">Conducteur</label>
                    <input
                            type="text"
                            class="form-control"
                            id="driver"
                            name="driver"
                            value="<?php echo e($trip->driver); ?>">
                </div>
                <div class="form-group">
                    <label for="typetrip">Type de déplacement</label>
                   
                    <select class="form-control" name="typetrip" value="<?php echo e($trip->typetrip); ?>">
                            <option id="typetrip" name="typetrips[]" value="personnel">personnel</option>
                            <option id="typetrip" name="typetrips[]" value="chantier">chantier</option>
                            <option id="typetrip" name="typetrips[]" value="quincaillerie">quincaillerie</option>
                            <option id="typetrip" name="typetrips[]" value="rendez-vous">rendez-vous</option>
                            <option id="typetrip" name="typetrips[]" value="administratif">administratif</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depart">Point de départ</label>
                    <input type="text" class="form-control" id="depart" name="depart" value="<?php echo e($trip->depart); ?>">
                </div>
                <div class="form-group">
                    <label for="arrivee">Destination</label>
                    <input type="text" class="form-control" id="arrivee" name="arrivee" value="<?php echo e($trip->arrivee); ?>">
                </div>
                <div>
                    <label class="radio-inline">
                    <input type="radio" name="singleTrip" id="singleTrip" value="1" <?php echo e(($trip->singleTrip == "1")? "checked" : ""); ?>>aller simple</option>
                    <label class="radio-inline">
                    <input type="radio" name="singleTrip" id="singleTrip" value="0" <?php echo e(($trip->singleTrip == "0")? "checked" : ""); ?>>aller-retour</option>
                </div>
                    <div class="form-group">
                    <label for="distance">Distance d'un aller simple</label>
                    <input type="text" class="form-control" id="distance" name="distance" value="<?php echo e($trip->distance); ?>">
                </div>
                <div class="form-group">
                    <label for="vehicle">Véhicule</label>
                    <input type="text" class="form-control" id="vehicle" name="vehicle" value="<?php echo e($trip->vehicle); ?>">
                </div>
               
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($trip_id); ?>">
                <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u318366483/domains/juliegrimala.com/public_html/resources/views/admin/edit.blade.php ENDPATH**/ ?>