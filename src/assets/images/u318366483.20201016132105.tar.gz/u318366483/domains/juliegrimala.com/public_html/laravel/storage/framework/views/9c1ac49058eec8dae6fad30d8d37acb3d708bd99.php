 <!-- name of folder . name of blade.php file -->

<?php $__env->startSection('content'); ?> <!-- to avoid breaking the html code -->
    <p class="quote">Mon kilométrage</p>
    <h1 class="post-title">Some content</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\juliekm\resources\views/welcome.blade.php ENDPATH**/ ?>