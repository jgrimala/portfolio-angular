@extends('layouts.master')
<!-- resources\views\widgetkm\index.blade.php -->
@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Tous les kilométrages</p>
        </div>
    </div>
    
    <div class="container">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Date de transport</th>
                <th scope="col">Conducteur</th>
                <th scope="col">Type de voyage</th>
                <th scope="col">Point de départ</th>
                <th scope="col">Destination</th>
                <th scope="col">Allée simple/retour</th>
                <th scope="col">Distance totale</th>
                <th scope="col">Véhicule</th>
            </tr>
        </thead>
        <tbody>
            @foreach($trips as $trip )
            <tr>
                <td style="font-weight: bold">{{ $trip->date }}</td>
                <td>{{ $trip->driver }}</td>
                <td>{{ $trip->typetrip }}</td>
                <td>{{ $trip->depart }}</td>
                <td>{{ $trip->arrivee }}</td>
                <td>@if($trip->singleTrip)
                        {{'Aller simple'}} 
                    @else {{ 'Aller-retour'}}
                    @endif</td>
                <td>@if(!$trip->singleTrip)
                        {{ $trip->distance*2 }} km
                    @else {{ $trip->distance }} km
                    @endif</td>
                <td>{{ $trip->vehicle }}</td>
                <td><a href="{{ route('widgetkm.trip', ['id' => $trip->id]) }}">Détails...</a></td>
            </tr>
            @endforeach
        </body>
    </table>
</div>
    <div class="row">
        <div class="col-md-12 text-center">
            {{ $trips->links() }}
        </div>
    </div>
@endsection