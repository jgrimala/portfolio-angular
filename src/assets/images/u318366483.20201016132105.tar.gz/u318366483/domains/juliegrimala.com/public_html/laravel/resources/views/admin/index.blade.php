@extends('layouts.master')

@section('content')
    @if(Session::has('info'))
    <div class="row">
        <div class="col-md-12">
            <p class="alert alert-info">{{ Session::get('info') }}</p>
        </div>
    </div>
    @endif
    <div class="row">
        <div class="col-md-12">
            <a href="{{ route('admin.create') }}" class="btn btn-success">New Post</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Tous les kilométrages</p>
        </div>
    </div>  
    <div class="container">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Date de transport</th>
                <th scope="col">Conducteur</th>
                <th scope="col">Type de voyage</th>
                <th scope="col">Point de départ</th>
                <th scope="col">Destination</th>
                <th scope="col">Distance totale</th>
            </tr>
        </thead>
        <tbody>
            @foreach($trips as $trip )
                @if($trip->driver = Auth::user()->name)
                    <tr>
                        <td style="font-weight: bold">{{ $trip->date }}</td>
                        <td>{{ $trip->driver }}</td>
                        <td>{{ $trip->typetrip }}</td>
                        <td>{{ $trip->depart }}</td>
                        <td>{{ $trip->arrivee }}</td>
                        <td>{{ $trip->distance }}</td>
                        <td>
                            <a href="{{ route('widgetkm.trip', ['id' => $trip->id]) }}">Détails  </a>
                            <a href="{{ route('admin.edit', ['id' => $trip->id]) }}">Modifier  </a>
                            <a href="{{ route('admin.delete', ['id' => $trip->id]) }}">Supprimer</a>
                        </td>
                    </tr>
                @endif
            @endforeach
        </body>
    </table>
</div>
@endsection
@section('content')

    <div class="row">
        <div class="col-md-12">
            <a href="{{ route('admin.create') }}" class="btn btn-success">Ajouter un kilométrage</a>
        </div>
    </div>
    <hr>
    @foreach($trips as $trip)
    <div class="row">
        <div class="col-md-12">
            <p style="font-weight: bold"><strong>{{ $trip->date }}</strong>
            ( {{ $trip->depart }}  à  {{ $trip->arrivee }} )
                
            </p>
        </div>
    </div>
    @endforeach
@endsection