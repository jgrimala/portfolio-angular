<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="<?php echo e(route('widgetkm.index')); ?>" class="navbar-brand">Accueil</a>
            <ul class="nav navbar-nav">
                <?php if(Auth::check()): ?>
                <li><a href="<?php echo e(route('widgetkm.index')); ?>">Déplacements</a></li>
                <?php endif; ?>
                <li><a href="#">About</a></li>
                <?php if(!Auth::check()): ?>
                <li><a href="<?php echo e(url('/login')); ?>">s'identifier</a></li>
                <li><a href="<?php echo e(url('/register')); ?>">s'enregistrer</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('admin.index')); ?>">Mon espace</a></li>
                <li>
                    <a href="<?php echo e(url('/logout')); ?>"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                        Se déconnecter
                    </a>

                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /home/u318366483/domains/juliegrimala.com/public_html/resources/views/partials/header.blade.php ENDPATH**/ ?>