
<!-- resources\views\widgetkm\trip.blade.php -->
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Kilométrage du : <?php echo e($trip->date); ?></p>
        </div>
    </div>
    <div class="row">
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Conducteur : <?php echo e($trip->driver); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Type de voyage : <?php echo e($trip->typetrip); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Point de départ : <?php echo e($trip->depart); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Destination : <?php echo e($trip->arrivee); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Allée simple/retour : <?php if($trip->singleTrip): ?>
                 <?php echo e('Aller simple'); ?> 
            <?php else: ?> <?php echo e('Aller-retour'); ?> </p>
            <?php endif; ?>
        
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Distance totale : <?php echo e($trip->distance); ?> km</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p>Véhicule : <?php echo e($trip->vehicle); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u318366483/domains/juliegrimala.com/public_html/resources/views/widgetkm/trip.blade.php ENDPATH**/ ?>