<?php
// routes\web.php
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', [
    'uses' => 'TripController@getIndex',
    'as' => 'widgetkm.index'
]);
Route::get('trip/{id}', [
    'uses' => 'TripController@getTrip',
    'as' => 'widgetkm.trip'
]);

Route::get('about', function () {
    return view('other.about');
})->name('other.about');
Route::group(['prefix' => 'admin'], function() {
    Route::get('', [
        'uses' => 'TripController@getAdminIndex',
        'as' => 'admin.index'
    ]);
    Route::get('create', [
        'uses' => 'TripController@getAdminCreate',
        'as' => 'admin.create'
    ]);
    Route::post('create', [
        'uses' => 'TripController@postAdminCreate',
        'as' => 'admin.create'
    ]);
    Route::get('edit/{id}', [
        'uses' => 'TripController@getAdminEdit',
        'as' => 'admin.edit'
    ]);
    Route::get('delete/{id}', [
        'uses' => 'TripController@getAdminDelete',
        'as' => 'admin.delete'
    ]);
    Route::post('edit', [
        'uses' => 'TripController@postAdminUpdate',
        'as' => 'admin.update'
    ]);
});
Auth::routes();
Route::post('login', [
    'uses' => 'SigninController@signin',
    'as' => 'auth.signin'
]);
