<?php
// app\Http\Controllers\TripController.php
namespace App\Http\Controllers;

use App\Like;
use App\Trip;
use App\Tag;
use App\User;
use Auth;
use Gate;
//use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;

class TripController extends Controller
{
    public function getIndex()
    {
        $trips = Trip::orderBy('created_at', 'desc')->paginate(4);
        return view('widgetkm.index', ['trips' => $trips]);
    }
    public function getAdminIndex()
    {
        if (!Auth::check()) {
            return redirect()->back();
        }

        $name = Auth::user()->name;
            
        $trips = Trip::where('driver', $name)->get();
        
        return view('admin.index', ['trips' => $trips]);
    }
    public function getTrip($id)
    {
        $trip = Trip::where('id', $id)->first();
        return view('widgetkm.trip', ['trip' => $trip]);
    }
    public function getAdminCreate()
    {
        if (!Auth::check()) {
            return redirect()->back();
        }
        //$tags = Tag::all();
        $users = User::all();
        return view('admin.create', ['users' => $users]);
    }
    public function getAdminEdit($id)
    {
        if (!Auth::check()) {
            return redirect()->back();
        }
        $trip = Trip::find($id);
        //$tags = Tag::all();
        $users = User::all();
        return view('admin.edit', ['trip' => $trip, 'trip_id' => $id, 'users' => $users]);
    }
    public function postAdminCreate(Request $request)
    {
        $user = Auth::user();
        if (!Auth::check()) {
            return redirect()->back();
        }    
        $this->validate($request, [
            'date' => 'required|date',
            'typetrip' => 'required',
            'depart' => 'required|string|min:3',
            'arrivee' => 'required|string|min:3',
            'singleTrip' => 'required',
            'distance' => 'required|integer',
            'arrivee' => 'required|string|min:3'
        ]);
        
        $trip = new Trip([
            'date' => $request->input('date'),
            'driver' => $user->name,
            'typetrip' => $request->input('typetrip'),
            'depart' => $request->input('depart'),
            'arrivee' => $request->input('arrivee'),
            'singleTrip' => $request->input('singleTrip'),
            'distance' => $request->input('distance'),
            'vehicle' => $request->input('vehicle'),
            
        ]);
        $user->trips()->save($trip);
        //$trip->users()->attach($request->input('users') === null ? [] : $request->input('users'));
        //$trip->tags()->attach($request->input('tags') === null ? [] : $request->input('tags'));

        return redirect()->route('admin.index')->with('info', 'Nouveau kilométrage ajouté pour la date du : ' . $request->input('date'));
    }
    public function postAdminUpdate(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->back();
        }
        $this->validate($request, [
            'date' => 'required|date',
            'typetrip' => 'required',
            'depart' => 'required|string|min:3',
            'arrivee' => 'required|string|min:3',
            'singleTrip' => 'required',
            'distance' => 'required|integer',
            'arrivee' => 'required|string|min:3'
        ]);
        $trip = Trip::find($request->input('id'));
        if (Gate::denies('modify-trip', $trip)) {
            return redirect()->back();
        }

        $trip->date = $request->input('date');
        $trip->driver = $request->input('driver');
        $trip->typetrip = $request->input('typetrip');
        $trip->depart = $request->input('depart');
        $trip->arrivee = $request->input('arrivee');
        $trip->singleTrip = $request->input('singleTrip');
        $trip->distance = $request->input('distance');
        $trip->vehicle = $request->input('vehicle');

        $trip->save();
        return redirect()->route('admin.index')->with('info', 'Kilométrage modifié pour la date du : ' . $request->input('date'));
    }
    public function getAdminDelete($id)
    {
        if (!Auth::check()) {
            return redirect()->back();
        }
        
        $trip = Trip::find($id);
        if (Gate::denies('modify-trip', $trip)) {
            return redirect()->back();
        }

        $trip->delete();
        return redirect()->route('admin.index')->with('info', 'Déplacement supprimé!');
    }
}
