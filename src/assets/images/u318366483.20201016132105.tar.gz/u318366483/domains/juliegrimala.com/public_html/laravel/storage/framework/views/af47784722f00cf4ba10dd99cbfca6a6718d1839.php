<?php $__env->startSection('content'); ?>
    <?php if(Session::has('info')): ?>
    <div class="row">
        <div class="col-md-12">
            <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-success">New Post</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Tous les kilométrages</p>
        </div>
    </div>
    
    <div class="container">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Date de transport</th>
                <th scope="col">Conducteur</th>
                <th scope="col">Type de voyage</th>
                <th scope="col">Point de départ</th>
                <th scope="col">Destination</th>
                <th scope="col">Distance totale</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($trip->driver = Auth::user()->name): ?>
                    <tr>
                        <td style="font-weight: bold"><?php echo e($trip->date); ?></td>
                        <td><?php echo e($trip->driver); ?></td>
                        <td><?php echo e($trip->typetrip); ?></td>
                        <td><?php echo e($trip->depart); ?></td>
                        <td><?php echo e($trip->arrivee); ?></td>
                        <td><?php echo e($trip->distance); ?></td>
                        <td>
                            <a href="<?php echo e(route('widgetkm.trip', ['id' => $trip->id])); ?>">Détails  </a>
                            <a href="<?php echo e(route('admin.edit', ['id' => $trip->id])); ?>">Modifier  </a>
                            <a href="<?php echo e(route('admin.delete', ['id' => $trip->id])); ?>">Supprimer</a>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </body>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-success">Ajouter un kilométrage</a>
        </div>
    </div>
    <hr>
    <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-12">
            <p style="font-weight: bold"><strong><?php echo e($trip->date); ?></strong>
            ( <?php echo e($trip->depart); ?>  à  <?php echo e($trip->arrivee); ?> )
                
            </p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\juliekm\resources\views/admin/index.blade.php ENDPATH**/ ?>